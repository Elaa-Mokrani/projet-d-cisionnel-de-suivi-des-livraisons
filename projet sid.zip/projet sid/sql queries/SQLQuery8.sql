SELECT * FROM VW_KPI_Delai_Par_Ville;
SELECT * FROM VW_KPI_Satisfaction;