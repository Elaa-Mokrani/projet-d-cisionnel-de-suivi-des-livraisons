
INSERT INTO FACT_LIVRAISON (
    ID_Livraison, ID_Commande, ID_Temps, ID_Ville, ID_Produit,
    Date_Commande, Date_Livraison, D�lai_Livraison,
    Statut_Livraison, Motif_Reclamation, Note_Client, Canal_Commande
)
SELECT 
    ROW_NUMBER() OVER (ORDER BY s.ID_Commande) AS ID_Livraison,
    s.ID_Commande,
    t.ID_Temps, -- Date_Livraison
    v.ID_Ville,
    p.ID_Produit,
    s.Date_Commande,
    s.Date_Livraison,
    DATEDIFF(DAY, s.Date_Commande, s.Date_Livraison),
    s.Statut_Livraison,
    s.Motif_Reclamation,
    s.Note_Client,
    s.Canal_Commande
FROM STG_LIVRAISON s
JOIN DIM_TEMPS t ON t.Date = s.Date_Livraison
JOIN DIM_VILLE v ON v.Ville = s.Ville
JOIN DIM_PRODUIT p ON p.Type_Produit = s.Type_Produit;
