INSERT INTO DIM_TEMPS (ID_Temps, Date, Mois, Ann�e)  -- Liste explicite des colonnes
SELECT DISTINCT
    CONVERT(INT, FORMAT(CONVERT(DATE, Date_Commande), 'yyyyMMdd')) AS ID_Temps,
    CONVERT(DATE, Date_Commande) AS Date,
    MONTH(CONVERT(DATE, Date_Commande)) AS Mois,
    YEAR(CONVERT(DATE, Date_Commande)) AS Ann�e
FROM STG_Livraison;