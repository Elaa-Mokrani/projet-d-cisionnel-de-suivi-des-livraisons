
-- Insertion unique des villes
INSERT INTO DIM_VILLE (ID_Ville, Ville, R�gion)
SELECT 
    ROW_NUMBER() OVER (ORDER BY DISTINCT_Villes.Ville) AS ID_Ville,
    DISTINCT_Villes.Ville,
    NULL AS R�gion
FROM (
    SELECT DISTINCT Ville
    FROM STG_LIVRAISON
) AS DISTINCT_Villes;
