

-- Insertion unique des produits
INSERT INTO DIM_PRODUIT (ID_Produit, Type_Produit, Cat�gorie)
SELECT 
    ROW_NUMBER() OVER (ORDER BY DISTINCT_Produits.Type_Produit) AS ID_Produit,
    DISTINCT_Produits.Type_Produit,
    NULL AS Cat�gorie
FROM (
    SELECT DISTINCT Type_Produit
    FROM STG_LIVRAISON
) AS DISTINCT_Produits;
