CREATE VIEW VW_Taux_Livraison_Temps AS
SELECT 
    COUNT(CASE WHEN Statut_Livraison = 'Livr�' AND D�lai_Livraison <= 3 THEN 1 END) * 100.0 / 
    NULLIF(COUNT(*), 0) AS Taux_Livraison_Temps
FROM FACT_LIVRAISON;
