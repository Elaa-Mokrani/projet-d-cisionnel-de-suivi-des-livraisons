
WITH Toutes_Dates AS (
    SELECT Date_Commande AS DateVal FROM STG_LIVRAISON
    UNION
    SELECT Date_Livraison FROM STG_LIVRAISON
)
INSERT INTO DIM_TEMPS (ID_Temps, Date, Jour, Mois, Trimestre, Ann�e, Jour_Semaine)
SELECT 
    ROW_NUMBER() OVER (ORDER BY DateVal) AS ID_Temps,
    DateVal,
    DAY(DateVal),
    MONTH(DateVal),
    DATEPART(QUARTER, DateVal),
    YEAR(DateVal),
    DATENAME(WEEKDAY, DateVal)
FROM Toutes_Dates;
