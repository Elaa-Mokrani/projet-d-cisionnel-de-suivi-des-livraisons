-- 1. D�lai moyen par ville (corrig�)
CREATE VIEW VW_KPI_Delai_Par_Ville AS
SELECT 
    Ville,
    AVG(DATEDIFF(day, CONVERT(DATE, Date_Commande), CONVERT(DATE, Date_Livraison))) AS D�lai_Moyen
FROM STG_Livraison
GROUP BY Ville;
GO  -- Ajout de GO pour s�parer les commandes

-- 2. Satisfaction client par canal
CREATE VIEW VW_KPI_Satisfaction AS
SELECT 
    Canal_Commande,
    AVG(CAST(Note_Client AS FLOAT)) AS Note_Moyenne
FROM STG_Livraison
GROUP BY Canal_Commande;
GO