--  Vue pour les d�lais moyens par ville
CREATE VIEW VW_Delai_Moyen_Par_Ville AS
SELECT 
    v.Ville,
    AVG(f.D�lai_Livraison) AS D�lai_Moyen,
    COUNT(*) AS Nombre_Commandes
FROM FACT_LIVRAISON f
JOIN DIM_VILLE v ON f.ID_Ville = v.ID_Ville
GROUP BY v.Ville;