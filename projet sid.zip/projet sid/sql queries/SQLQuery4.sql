-- 1. Vue pour le taux de livraisons � temps (d�lai ? 3 jours)
CREATE VIEW VW_Taux_Livraisons_Temps AS
SELECT 
    (COUNT(CASE WHEN Statut_Livraison = 'Livr�' AND D�lai_Livraison <= 3 THEN 1 END) * 100.0 / 
    COUNT(*)) AS Taux_Livraison_Temps
FROM FACT_LIVRAISON;