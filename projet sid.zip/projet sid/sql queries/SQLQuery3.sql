
-- 2. Cr�ez une vue simplifi�e pour le KPI "Taux de livraison � temps"
CREATE VIEW VW_KPI_Livraison_Simple AS
SELECT 
    (COUNT(CASE WHEN Statut_Livraison = 'Livr�' AND 
          DATEDIFF(day, CONVERT(DATE, Date_Commande), CONVERT(DATE, Date_Livraison)) <= 3 
          THEN 1 END) * 100.0 / 
    COUNT(*)) AS Taux_Livraison_Temps
FROM STG_Livraison;

