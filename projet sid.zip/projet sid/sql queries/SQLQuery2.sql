USE DW_Livraison;
GO

CREATE TABLE STG_Livraison (
    ID_Commande NVARCHAR(20),
    Date_Commande DATETIME,
    Date_Livraison DATETIME,
    Ville NVARCHAR(100),
    Statut_Livraison NVARCHAR(50),
    Motif_Reclamation NVARCHAR(255),
    Note_Client INT,
    Canal_Commande NVARCHAR(50),
    Type_Produit NVARCHAR(50)
);