CREATE VIEW VW_Satisfaction_Par_Canal AS
SELECT 
    Canal_Commande,
    AVG(Note_Client * 1.0) AS Note_Moyenne
FROM FACT_LIVRAISON
GROUP BY Canal_Commande;

