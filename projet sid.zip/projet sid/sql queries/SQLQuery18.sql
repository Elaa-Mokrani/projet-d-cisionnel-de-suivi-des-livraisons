-- 1. V�rifiez l'exhaustivit� des jointures
SELECT 
    (SELECT COUNT(*) FROM STG_Livraison) AS Source,
    (SELECT COUNT(*) FROM FACT_LIVRAISON) AS Destination,
    (SELECT COUNT(DISTINCT ID_Commande) FROM FACT_LIVRAISON) AS Commandes_Uniques;

-- 2. Contr�lez les incoh�rences potentielles
SELECT 
    COUNT(CASE WHEN D�lai_Livraison < 0 THEN 1 END) AS D�lais_N�gatifs,
    COUNT(CASE WHEN Note_Client NOT BETWEEN 1 AND 5 THEN 1 END) AS Notes_Invalides
FROM FACT_LIVRAISON;